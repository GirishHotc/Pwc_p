"""
Tests for python app
"""
